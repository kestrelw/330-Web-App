// enum drawParams {
//       showGradient = false,
//       showBars = false,
//       showCircles = false,
//       showNoise = false,
//       showInvert = false,
//       showEmboss = false
//     };

// export {drawParams};