enum DEFAULTS {
    gain = 0.5,
    numSamples = 256
}

export {DEFAULTS};