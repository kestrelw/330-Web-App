interface ColorStop{
    
    // etc ...
}

export {ColorStop};