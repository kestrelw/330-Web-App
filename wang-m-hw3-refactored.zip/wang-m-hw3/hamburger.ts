// //mobile menu

// const burgerIcon = document.querySelector('#burger') as Element;
// const navbarMenu = document.querySelector('#nav-links') as Element;

// burgerIcon.addEventListener('click', () =>{
//     navbarMenu.classList.toggle('is-active');
// });